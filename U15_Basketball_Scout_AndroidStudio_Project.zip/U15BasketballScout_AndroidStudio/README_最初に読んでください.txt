# U15 Basketball Scout - Android APK project

## APKの作り方（Android Studio）
1. PCにAndroid Studioをインストールします。
2. このZIPを展開します。
3. Android Studioで展開した `U15BasketballScout_AndroidStudio` フォルダを開きます。
4. Gradle Syncを完了させます（Android SDK Platform 35が必要です）。
5. メニューの Build > Build Bundle(s) / APK(s) > Build APK(s) を選びます。
6. 完成したAPKは `app/build/outputs/apk/debug/app-debug.apk` に出力されます。
7. APKをAndroidスマホへ送り、インストールを許可してインストールします。

## PCがない場合
GitHubにこのプロジェクトをアップロードし、Actionsの「Build Android APK」を実行すると、実行結果のArtifactsからAPKを取得できます。

## 実装内容
- 元のU15 Basketball Scout HTMLをアプリ内に同梱
- Android WebViewでアプリ画面として表示
- JavaScriptと端末内保存（localStorage）を有効化
- WebViewAssetLoaderのHTTPS相当オリジンを使い、カメラAPIを利用可能にする構成
- Androidカメラ権限を実行時に要求

## 注意
- この作成物はAndroid Studioプロジェクトであり、APKバイナリではありません。
- 実機での最終テスト（カメラ権限、静止画保存、印刷・ファイル書き出し）は必要です。
- データはアプリ内WebViewのローカル領域に保存されます。アプリ削除時に消える可能性があるため、試合データを書き出してバックアップしてください。
